package com.example.android.locationfinder.Modules;

/**
 * Created by Mai Thanh Hiep on 4/3/2016.
 */
public class Duration {
    public String text;
    public int value;

    public Duration(String text, int value) {
        this.text = text;
        this.value = value;
    }
}
