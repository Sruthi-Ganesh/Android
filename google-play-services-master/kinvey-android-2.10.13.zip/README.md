
Welcome to the Kinvey client library for Android.  Simply add the jar files contained in 
this distributions libs directory to your build path and you're ready to go.  We've also included a few sample projects to help you get started.

Documentation
-------------

For instructions on integrating this library with your Android project, see:

http://devcenter.kinvey.com/android/guides/getting-started

For Javadoc, see:

http://devcenter.kinvey.com/android/reference/api/reference/packages.html

